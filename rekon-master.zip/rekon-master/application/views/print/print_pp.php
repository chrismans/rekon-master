<pre> <font face="arialblack">
    PT.REKA MULIA KONSTRUKSI
    PROYEK GREEN LAND FOREST HILL
    PEKERJAAN PEMBANGUNAN 14 UNIT TAHAP 9A
    SPK 6/044-3/TEK/GD3-RRI
    TGL SPK 27-FEB-2015
    </font>
</pre>   
<hr>
<style type="text/css"></style>


<div class="container"><br><br>
                <b>A. Kontrak Pekerjaan</b><br>
                <table>
                <tr>
                <td><p>&nbsp&nbsp&nbsp&nbsp Nilai Kontrak</p> </td>
                <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 1,885,438,920</td>
                </tr>
                <tr>
                <td><p>&nbsp&nbsp&nbsp&nbsp Jasa Kontruksi 10%</p></td>
                <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp (171,403,538)<hr></td>
                </tr>
                <table>
                <tr>
                <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp NK Setelah Jasa</td>
                <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp1,714,035,381</td>
                </tr>
                 </table>
                <table>
                    <tr><b>Anggaran</b>
                    <td>Material</td>
                    <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 1,420,985,381,42</td>
                    </tr>
                </table>
                <table>
                    <td>Upah Mandor (IPL)</td>
                    <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 293,050,000.00&nbsp&nbsp(17%)</td>
                    </tr>
                </table>                
                </table>
                <br>
                <b>B. Realisasi Biaya Kontruksi</b><br>
                
                <table>
                    <td>Material</td>
                    <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 931.859.491&nbsp&nbsp(66%)</td>
                   
                </table> 
                
                <table>
                    <td>Upah</td>
                    <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 292.295.500&nbsp&nbsp(100%)</td>
                </table>
                <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspTotal Bayar&nbsp&nbsp&nbsp&nbsp&nbsp1,224,154,991&nbsp&nbsp(71%)</td>
                <br>
                <b>C. Sisa Anngaran (A-B) &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 489.880.390&nbsp&nbsp&nbsp&nbsp(29%)</b>
                <br><br>
                <b>D. Waktu Pelaksanaan & Masa Retensi</b><br>                                                                                
                <div class="col s12 m8 l9">
                  
                  <table id="data-table-simple" class="responsive-table display dataTable" cellspacing="0" role="grid" aria-describedby="data-table-simple_info" border="1">
                    <thead>
                        <th class="sorting" tabindex="0" aria-controls="data-table-simple" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 200px;">Pelaksanaan :</th>    
                        <th class="sorting" tabindex="0" aria-controls="data-table-simple" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 200px;">120</th>    
                        <th class="sorting" tabindex="0" aria-controls="data-table-simple" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 200px;">Hari Kerja</th>    
                        <th class="sorting" tabindex="0" aria-controls="data-table-simple" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 450px;">Realisasi Pelaksanaan - IPL Mandor</th>    

                    </thead>
                 
                    <tbody>
                    <tr role="row" class="odd">
                      <td align="center">27-feb-15</td>
                      <td align="center">Sd</td>
                      <td align="center">27-jun-15</td>
                      <td>-</td>
                      <td>-</td>
                      <td>-</td>
                      <td>-</td>
                      </tr>
                      <hr>
                          <th class="sorting" tabindex="0" aria-controls="data-table-simple" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 200px;" height="38px;">Retensi Berakhir :</th>    
                          <th class="sorting" tabindex="0" aria-controls="data-table-simple" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 200px;">100</th>    
                          <th class="sorting" tabindex="0" aria-controls="data-table-simple" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 200px;">Hari Kerja </th>    
                        
                    <tr role="row" class="odd">
                      <td align="center">27-jun-15</td>
                      <td align="center">Sd</td>
                      <td align="center">5-oct-jun-15</td>
                      </tr>

                    </tbody>
                    <br><br>
                </div>
              </div>
            </div>
            </table>